from appJar import gui

with gui('Lesson 1') as app:
    app.label('Where to begin?')
