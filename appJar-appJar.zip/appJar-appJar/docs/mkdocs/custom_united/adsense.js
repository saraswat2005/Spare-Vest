<script>
    (adsbygoogle = window.adsbygoogle || []).push({
        google_ad_client: "ca-pub-6185596049817878",
        enable_page_level_ads: true
    });
</script>
