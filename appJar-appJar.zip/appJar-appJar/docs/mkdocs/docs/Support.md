##Support
---
This is an open source project, freely available on [GitHub](https://github.com/jarvisteach/appJar).  
Click: 
<a class="github-button" href="https://github.com/jarvisteach/appJar/issues/new" data-icon="octicon-issue-opened" aria-label="Issue jarvisteach/appJar on GitHub">Issue</a> to raise an issue.  

The code on GitHub will always be the most up-to-date.  
If you want the latest fixes & enhancements - try out the [development branch](https://github.com/jarvisteach/appJar/tree/next_release).  

If you want to update your existing code, just replace the [appjar.py file](https://raw.githubusercontent.com/jarvisteach/appJar/appJar/appjar.py)   
Zip files are available to download from the [releases folder](https://github.com/jarvisteach/appJar/tree/appJar/releases)  
