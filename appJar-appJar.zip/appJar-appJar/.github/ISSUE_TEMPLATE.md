# Bug Report
---

## Context
---
Replace this with a bit of background on what you're doing.  

## Expected Behaviour
---
Replace this with what you expect to happen.  

## Actual Behaviour
---
Replace this with what does happen.  

## Any error messages produced by appJar
---
Replace this with any error messages that are produced.  

## Sample code, demonstrating the issue
---
Replace this with a cut-down version of code, that demonstrates the issue.  

## What steps are needed to reproduce the bug
---
Replace this with the steps we should follow to reproduce the bug.  

## Version Information
---
Replace this with the result of running your code with the -v flag: `python myCode.py -v`
